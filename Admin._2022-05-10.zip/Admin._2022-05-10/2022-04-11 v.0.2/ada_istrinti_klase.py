import time

class adaIstrintiKla:
    
    """
    @param rinkmenaFailas - konkretus rinkmenos pavadinimas.
    @param rinkmenosFailoFormatas - konkretus rinkmenos formatas.
    @param rinkmenosFailoAntraste - konkreti rinkmenos antraštė
    leidžianti nustatyti reikalingą aplikaciją paleidimui. 
    """
    
    rinkmenaFailas = "Kada"
    rinkmenosFailoFormatas = "ICS"
    rinkmenosFailoAntraste = "text/calendar"

    """
    @func Klasė  įgyvendinima ada klasės vyksmo metu, t.y. obj.nustatytiFunkcReq
    @args nil
    """

    def __init__(self):
        self.adaFunkcinioReikalavimoPav = "Ištrinti pasirinktus duomenis iš ICS failo-rinkmenos."
        self.adaFunkcinioReikalavimoApr = "Iš numatyto failo-rinkmenos ištrinti duomenis apie Įvykį(-ius)."
        self.rinkmenosFailoTurinys = ""

    """
    @func nustatymai
    @args nil
    """

    def nustatymai(self):
        print("Aktyvus funkcinis reikalavimas: " + str(self.adaFunkcinioReikalavimoPav))
        

    """
    @func adaKeistiNustatymus
    @args nil
    """

    def adaKeistiNustatymus(self):
        print("\t...")
        

    """
    @func adaPaleistiFunkcReq
    @args nil
    """

    def adaPaleistiFunkcReq(self):
        self.nustatymai()
        parametras = input("Ar ištrynimo nustatymai tenkina? (t/n)")
        if (parametras == "t" or parametras == "T"):
            self.adaKeistiNustatymus()
        else:
            print("Nustatymai palikti nepakitę.")
        del(parametras)

        print("Laikas ir data: " + str(time.ctime()))
        
