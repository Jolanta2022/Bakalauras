import time
import re
import os
import subprocess

class adaIkeltiKla:

    """
    @param rinkmenaFailas - konkretus rinkmenos pavadinimas.
    @param rinkmenosFailoFormatas - konkretus rinkmenos formatas.
    @param rinkmenosFailoAntraste - konkreti rinkmenos antraštė
    @param kalendorius - kalendoriaus duomenys ICS rinkmenos sukūrimui
    @param loop - kalendoriaus dedamosios
    @param eol - skiriamasis naujos eilutės simbolis
    @param ptn - skiriamasis simbolis keliui iki rinkmenos nusakyti
    leidžianti nustatyti reikalingą aplikaciją paleidimui. 
    """

    rinkmenaFailas = "Kada"
    rinkmenosFailoFormatas = "ICS"
    rinkmenosFailoAntraste = "text/calendar"
    kalendorius = {}
    loop = ('BEGIN', 'UID', 'NAME', 'DTSTAMP', 'SUMMARY', 'DESCRIPTION', 'LOCATION', 'CREATED', 'LAST-MODIFIED', 'END')
    eol = "\n"
    pth = "/"
    
    """
    @func Klasė įgyvendinima ada klasės vyksmo metu, t.y. obj.nustatytiFunkcReq
    @args nil
    """
    
    def __init__(self):
        self.adaFunkcinioReikalavimoPav = "Įkelti naujus duomenis į ICS failą-rinkmeną."
        self.adaFunkcinioReikalavimoApr = "Į numatytą failą-rinkmeną įkelti informaciją apie Įvykį. Versija X."
        self.rinkmenosFailoTurinys = ""
        self.bandomasisTurinys()

    
    """
    @func bandomasisTurinys
    @args nil
    """

    def bandomasisTurinys(self):
        self.kalendorius['BEGIN'] = ['VEVENT']
        self.kalendorius['BEGIN'].append('VEVENT')
        self.kalendorius['BEGIN'].pop()
        self.kalendorius['UID'] = ['58747ec2f464ff98797142c519189ce375021917']
        self.kalendorius['UID'].append('58747ec2f464ff98797142c519189ce375021917')
        self.kalendorius['UID'].pop()
        self.kalendorius['NAME'] = ['įvykį specifikuojantis parametras']
        self.kalendorius['DTSTAMP'] = ['D20220217T173228UTC0200']
        self.kalendorius['DTSTAMP'].append('D20220217T173228UTC0200')
        self.kalendorius['DTSTAMP'].pop()
        self.kalendorius['SUMMARY'] = ['įvykio pavadinimas pagal įvykį specifikuojantį parametrą']
        self.kalendorius['DESCRIPTION'] = ['įvykio aprašas']
        self.kalendorius['LOCATION'] = ['Vilnius']
        self.kalendorius['CREATED'] = ['D20220217T170438UTC0200']
        self.kalendorius['LAST-MODIFIED'] = ['D20220217T170438UTC0200']
        self.kalendorius['END'] = ['VEVENT']
        
            
    """
    @func Nustatymai
    @args nil
    """

    def nustatymai(self):
        print("Aktyvus funkcinis reikalavimas: " + str(self.adaFunkcinioReikalavimoPav))
        print("Bandomasis Turinys:")
        print(self.kalendorius)

    """
    @func adaKeistiNustatymus
    @args nil
    """

    def adaKeistiNustatymus(self, keisti = True):
        
        i = 0
        il = len(self.loop)
        if (keisti == True):
            for i in range(il):
                dmn = ""
                print("\tParametras [" + str(self.loop[i]) + "]")
                print("\t" + str(self.kalendorius[str(self.loop[i])]))
                value = input("(" + str(i) + "/" + str(il) +") Ar keisti [" + str(self.loop[i]) + "] parametro informaciją? (t/n)")
                if(value == "t" or value == "T"):
                    dmn = input("Įvesti naują " + str(self.loop[i]) + " informaciją:\n")
                    self.kalendorius[str(self.loop[i])].pop()
                    self.kalendorius[str(self.loop[i])].append(str(dmn))
                print("\t(" + str(i) + ") Parametras [" + str(self.loop[i]) + ":" + str(dmn) + "]")
                del(value)
        
        pwd = subprocess.run(["pwd"], capture_output=True)
        pwd_str = pwd.stdout.decode()
        print(pwd_str)
        match = re.search(r"\n", pwd_str)
        if match:
            pwd_string = pwd_str[:match.start()]
            pwd_string_len = len(pwd_string)
            if (pwd_string[pwd_string_len-1] != self.pth):
                pwd_string = pwd_string + self.pth
            path = pwd_string + str(self.rinkmenaFailas) + '.' + str(self.rinkmenosFailoFormatas)
        else:
            pwd_string = pwd_str
            pwd_string_len = len(pwd_string)
            if (pwd_string[pwd_string_len-1] != self.pth):
                pwd_string = pwd_string + self.pth
            path = pwd_string + str(self.rinkmenaFailas) + '.' + str(self.rinkmenosFailoFormatas)
        if (os.path.exists(path)):
            """ exists """
            with open(path, "r") as f:
                data = f.readlines()
            
            with open(path, "w") as f:
                for line in data:
                    if line.strip("\n") != "END:VCALENDAR":
                        f.write(line)
            
            f.close()
        else:
            file_con = open(path, 'x')
            file_con.close()
            
            file_con = open(path, 'a')
            file_con.write("BEGIN:VCALENDAR" + self.eol + "VERSION:X.2" + self.eol)
            file_con.close()
            print("\t...")
        
        file_con = open(path, 'a')
        
        i = 0
        for i in range(il):
            dmn = str(self.kalendorius[str(self.loop[i])])
            file_con.write(str(self.loop[i]) + ":" + dmn[2:-2] + self.eol)        
            
        
        file_con.write("END:VCALENDAR" + self.eol)
        file_con.close()
        print("\t...\t...")
    
    
    """
    @func adaPaleistiFunkcReq
    @args nil
    """
    
    def adaPaleistiFunkcReq(self):
        self.nustatymai()
        
        parametras = input("Ar valdyti įkėlimo nustatymus? (t/n)")
        if (parametras == "t" or parametras == "T"):
            self.adaKeistiNustatymus(keisti = True)
        else:
            self.adaKeistiNustatymus(keisti = False)
        del(parametras)

        print("Laikas ir data: " + str(time.ctime()))
        
