#!/usr/bin/python3
# coding=UTF-8

from ada_ikelti_klase import adaIkeltiKla
from ada_istrinti_klase import adaIstrintiKla
import sys

class ada:

    """
    @param funkciniai_reikalavimai - Funkcinių Reikalavimų Sąrašas atitinkamam funkcionalumui įgyvendinti.
    @param funkcinis_reikalavimas - šiuo metu aktualus Funkcinis Reikalavimas.
    """
    
    funkciniai_reikalavimai = (adaIkeltiKla, adaIstrintiKla)
    funkcinis_reikalavimas = [adaIkeltiKla]
    
    """
    @func Įgyvendinama klasės apibrėžimo metu: obj = ada()
    Atvaizduojama Pre-Procesoriaus nustatymuose įvesta koduotė.
    @args nil
    """
    
    def __init__(self):
        print("Naudojama koduotė: " + sys.getfilesystemencoding())
        self.ada = self.funkcinis_reikalavimas[0]()
    
    
    """
    @func paruostiVisusFunkcReq - paruošia informaciją apie
    Funkcinius Reikalavimus.
    @args nil
    @back perduoda užprašytą informaciją apie naudojamus
    Funkcinius Reikalavimus.
    """
    
    def paruostiVisusFunkcReq(self):
        fr_sara = []
        
        for vienetas in self.funkciniai_reikalavimai:
            y = vienetas()
            fr_bib = {}
            fr_bib["FunkcinioReikalavimoPav"] = y.adaFunkcinioReikalavimoPav
            fr_bib["FunkcinioReikalavimoApr"] = y.adaFunkcinioReikalavimoApr
            fr_sara.append(fr_bib)
        
        return fr_sara
    
    
    """
    @func vaizduotiNustatymus - atspausdinti turimus duomenis apie
    šiuo metu aktualius nustatymus. Neaktualu.
    @args nil
    """
    
    def vaizduotiNustatymus(self):
        print("Programėlė skirta Įvykių kalendoriaus naudojantis ICS failo-rinkmenos formatu suformavimui.")
        print("Numatytas funkcinis reikalavimas: " + str(self.numatytasFunkcReq()) + "." )
        
        funkciniai_reikalavimai = self.paruostiVisusFunkcReq()
        
        i = 1
        
        for vienetas in funkciniai_reikalavimai:
            print("[" + str(i) + "] " + vienetas["FunkcinioReikalavimoPav"])
            i = i + 1
        
        print(" ")
    
    
    """
    @func vaizduotiNumatytusNustatymus - saviti-aktualūs klasės
    nustatymai - paruoštukė.
    @args nil
    """
    
    def vaizduotiNumatytusNustatymus(self):
        print("Numatyti nustatymai:")
        self.ada.nustatymai()
        print("")
    
    
    """
    @func numatytasFunkcReq - Funkcinis Reikalavimas
    šiuo metu numatytas kaip pagrindinis-aktualus.
    @args nil
    """
    
    def numatytasFunkcReq(self):
        if(self.funkcinis_reikalavimas):
            x = self.funkcinis_reikalavimas[0]
            y = x()
            return y.adaFunkcinioReikalavimoPav
        else:
            return ""
    
    
    """
    @func nustatytiVisusFunkcReq - užkrauti klasės informaciją apie
    įtraukiamus-importuojamą papildomą informaciją susijusią su
    Funkciniais Reikalavimais.
    @args nil
    """
    
    def nustatytiVisusFunkcReq(self):
        self.fr_sara = []

        for vienetas in self.funkciniai_reikalavimai:
            y = vienetas()
            fr_bib = {}
            fr_bib["FunkcinioReikalavimoPav"] = y.adaFunkcinioReikalavimoPav
            fr_bib["FunkcinioReikalavimoApr"] = y.adaFunkcinioReikalavimoApr
            self.fr_sara.append(fr_bib)

        print("")
    
    
    """
    @func vaizduotiVisusFunkcReq - atspausdinti turimus duomenis
    apie Funkcinius Reikalavimus.
    @args parametras - Įmanoma reikšmė "visi"nusakanti atspausdinti
    papildomą Funkcinio Reikalavimo Aprašą.
    """
    
    def vaizduotiVisusFunkcReq(self, parametras):
        fr_sara = []

        for vienetas in self.funkciniai_reikalavimai:
            y = vienetas()
            fr_bib = {}
            fr_bib["FunkcinioReikalavimoPav"] = y.adaFunkcReikalavimoPav
            fr_bib["FunkcinioReikalavimoApr"] = y.adaFunkcinioReikalavimoApr
            fr_sara.append(fr_bib)

        i = 1
        x = len(fr_sara)
        while i < x:
            i += 1
            print(str(i) + ". " + fr_sara[i-1]["FunkcinioReikalavimoPav"])
            if parametras == "visi":
                print(fr_sara[i-1]["FunkcinioReikalavimoApr"])
            if i == x:
                break
        else:
            print("Funkcinių reikalavimų nėra numatyta.")

        print("")
    
    
    """
    @func nustatytiFunkcReq - pasirinkti funkcinį reikalavimą
    pagal parametrą - funkciniai_reikalavimai.
    @args parametras - skaičius eilėstvarka pasirenkant
    funkcinį reikalavimą.
    """
    
    def nustatytiFunkcReq(self, parametras):
        x = len(self.funkciniai_reikalavimai)
        nustatyti = int(parametras)
        if(nustatyti >= 1 and nustatyti < x):
            self.funkcinis_reikalavimas = [self.funkciniai_reikalavimai[nustatyti-1]]
            del(self.ada)
            self.ada = self.funkcinis_reikalavimas[0]()
            print("Numatytas funkcinis reikalavimas: " + str(self.numatytasFunkcReq()))
        else:
            print("Funkcinis reikalavimas nenumatytas.")


obj = ada()

run = 44

"""
@purp Pateikti pasirinkimų sąrašą ir pagal poreikį juos paleisti.
@foll Įgyvendinamas ciklas tol kol netenkinama įvesties sąlyga.
"""

obj.vaizduotiNustatymus()

while(run == 44):
    
    along_pir = list(enumerate(['^[[A', '\x1b[A'], start=0))
    back_atg = list(enumerate(['^[[B', '\x1b[B'], start=0))
    
    parametras = input("Pasirinkite funkcinį reikalavimą: \n")
    
    if((parametras == along_pir[1][1]) or (parametras == along_pir[1][0])):
        print(" ")
        print("Pirmyn")
    elif((parametras == back_atg[1][1]) or (parametras == back_atg[1][0])):
        print(" ")
        print("Atgal")
    elif(parametras == ' ' or parametras == ''):
        print(" ")
        print("Išeiti...")
        run = 0
        sys.exit(0)
        exit()
    elif(int(parametras) == 0):
        print(" ")
        print("Išeiti...")
        run = 0
        sys.exit(0)        
        exit()
    elif(int(parametras) == 1):
        
        obj.nustatytiFunkcReq(parametras)
        
        if(obj.ada):
            obj.ada.adaPaleistiFunkcReq()
        else:
            print("Nepaleistas funkcinis reikalavimas. Jokių veiksmų nevykdyta.")
    elif(int(parametras) == 2):
        
        obj.nustatytiFunkcReq(parametras)
        
        if(obj.ada):
            obj.ada.adaPaleistiFunkcReq()
        else:
            print("Nepaleistas funkcinis reikalavimas. Jokių veiksmų nevykdyta.")
    elif(int(parametras) == 22):
        obj.vaizduotiVisusFunkcReq("min")
        lok = input("Nustatyti pagrindinį reikalavimą:")
        obj.nustatytiFunkcReq(lok)
    elif(int(parametras) == 3):
        if(obj.ada):
            obj.ada.adaPaleistiFunkcReq()
        else:
            print("Nepaleistas funkcinis reikalavimas. Jokių veiksmų nevykdyta.")
    else:
        print(" ")
        print("Pradedam iš naujo...")
        
        obj.vaizduotiNustatymus()
        
        run = 44
