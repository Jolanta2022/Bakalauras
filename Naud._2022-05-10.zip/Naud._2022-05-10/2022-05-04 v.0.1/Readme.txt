Prerequirements:

sudo apt-get install python-tk
pip3 install python-dateutil
