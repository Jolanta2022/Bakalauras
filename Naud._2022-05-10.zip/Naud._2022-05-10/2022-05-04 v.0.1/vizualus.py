#!/usr/bin/env python
# coding=UTF8

from tkinter import *
from datetime import *
from dateutil.relativedelta import *
import time
import calendar
import datetime

root = Tk()

root.geometry("800x400")
root.title("KAL")
root.config(bg = "white")

#D20220217T173228UTC0200

curr = date.today()
global curr_delta 
curr_delta = curr

curr_year_p =  curr.year
curr_month_p = curr.month
curr_day_p = curr.day

next_month = curr+relativedelta(months=+1)
prev_month = curr+relativedelta(months=-1)
next_month_p = next_month.month
prev_month_p = prev_month.month

next_year = curr+relativedelta(years=+1)
prev_year = curr+relativedelta(years=-1)
next_year_p = next_year.year
prev_year_p = prev_year.year

year_label_var = StringVar()
month_label_var = StringVar()

clicked_noth = StringVar()
clicked_utc = StringVar() 

selection_noth = StringVar()
selection_utc = StringVar()

options_noth = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday"
]

options_utc = [
    "UTC-12:00",
    "UTC-11:00",
    "UTC-10:00",
    "UTC-09:00",
    "UTC-08:00",
    "UTC-07:00",
    "UTC-06:00",
    "UTC-05:00",
    "UTC-04:00",
    "UTC-03:00",
    "UTC-02:00",
    "UTC-01:00",
    "UTC+00:00",
    "UTC+01:00",
    "UTC+02:00",
    "UTC+03:00",
    "UTC+04:00",
    "UTC+05:00",
    "UTC+06:00",
    "UTC+07:00",
    "UTC+08:00",
    "UTC+09:00",
    "UTC+10:00",
    "UTC+11:00",
    "UTC+12:00"
]

clicked_noth.set("Monday")
selection_noth.set("Monday")

clicked_utc.set("UTC+00:00")
selection_utc.set("UTC+00:00")

year_label_var.set(curr.year)
month_label_var.set(curr.month)

def submit_next_month(curr_delta):
	curr_delta = curr_delta+relativedelta(months=+1)
	month_label_var.set(curr_delta.month)


def submit_prev_month(curr_delta):
	curr_delta = curr_delta+relativedelta(months=-1)
	month_label_var.set(curr_delta.month)


def submit_next_year(curr_delta):
	curr_delta = curr_delta+relativedelta(years=+1)
	year_label_var.set(curr_delta.year)


def submit_prev_year(curr_delta):
	curr_delta = curr_delta+relativedelta(years=-1)
	year_label_var.set(curr_delta.year)


def reset():
	clicked_noth.set("Monday")
	selection_noth.set("Monday")

	clicked_utc.set("UTC+00:00")
	selection_utc.set("UTC+00:00")

	curr = date.today()
	year_label_var.set(curr.year)
	month_label_var.set(curr.month)


def show():
	selection_noth.set(clicked_noth.get())
	selection_utc.set(clicked_utc.get())


submit_prev_year_btn = Button(root, text = '<', command = lambda : submit_prev_year(curr_delta)).grid(row=0,column=0)

year_la = Label(root, text = 'Year', font = ('Palem3.2.05-nm.ttf', 12, 'normal')).grid(row=0,column=1)

seyear_la = Label(root, textvariable = year_label_var, font = ('Palem3.2.05-nm.ttf', 12, 'normal')).grid(row=0,column=2)

submit_next_year_btn = Button(root, text = '>', command = lambda : submit_next_year(curr_delta)).grid(row=0,column=3)

submit_prev_month_btn = Button(root, text = '<', command = lambda : submit_prev_month(curr_delta)).grid(row=1,column=0)

month_la = Label(root, text = 'Month', font = ('Palem3.2.05-nm.ttf', 12, 'normal')).grid(row=1,column=1)

semonth_la = Label(root, textvariable = month_label_var, font = ('Palem3.2.05-nm.ttf', 12, 'normal')).grid(row=1,column=2)

submit_next_month_btn = Button(root, text = '>', command = lambda : submit_next_month(curr_delta)).grid(row=1,column=3)


drop_noth = OptionMenu(root, clicked_noth, *options_noth).grid(row=0,column=5)

label_noth = Label(root, textvariable = selection_noth, font = ('Palem3.2.05-nm.ttf', 12, 'normal')).grid(row=0,column=6)

drop_utc = OptionMenu(root , clicked_utc, *options_utc).grid(row=1,column=5)

label_utc = Label(root, textvariable = selection_utc, font = ('Palem3.2.05-nm.ttf', 12, 'normal')).grid(row=1,column=6)

button_rst = Button(root, text = "Reset", command = reset).grid(row=0,column=7)

button_shw = Button(root, text = "Settings", command = show).grid(row=1,column=7)


root.mainloop()

